<!.... Footer Section starts ...>
       <div class="footer">
           <div class="wrapper">
               <p class="text-center">2022 all right reserved , Food House, developed by Niloy </p>

           </div>
       </div>
       <!.... Footer Section ends ...>
    </body>
</html>