<?php
   //include constants.php for SITEURL
   include('../config/constants.php');


   //1. Destroy the session 
    session_destroy();  // UNsets $_session['user]


   //2. Redirect to login page
header('location:'.SITEURL.'admin/login.php');

?>